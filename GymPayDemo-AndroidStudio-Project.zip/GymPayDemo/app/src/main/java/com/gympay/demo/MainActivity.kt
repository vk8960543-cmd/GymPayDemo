package com.gympay.demo

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2738)
private val Lime = Color(0xFFB8F36B)
private val Muted = Color(0xFF9AA8BA)
private data class Member(val name: String, val phone: String, val fee: Int, val due: String, val paid: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymPayApp() }
    }
}

@Composable
private fun GymPayApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iron_house_demo", 0) }
    val members = remember {
        mutableStateListOf<Member>().apply {
            val saved = prefs.getString("members", null)
            if (saved == null) {
                addAll(listOf(
                    Member("Rahul Sharma", "919876543210", 1200, "05 Nov 2026", false),
                    Member("Aman Singh", "919876543211", 1200, "04 Nov 2026", true),
                    Member("Vikram Gupta", "919876543212", 1500, "10 Nov 2026", false),
                    Member("Sahil Kumar", "919876543213", 1000, "01 Nov 2026", true)
                ))
            } else {
                val arr = JSONArray(saved)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(Member(o.getString("name"), o.getString("phone"), o.getInt("fee"), o.getString("due"), o.getBoolean("paid")))
                }
            }
        }
    }
    fun persist() {
        val arr = JSONArray()
        members.forEach { m -> arr.put(JSONObject().put("name", m.name).put("phone", m.phone).put("fee", m.fee).put("due", m.due).put("paid", m.paid)) }
        prefs.edit().putString("members", arr.toString()).apply()
    }
    var showAdd by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newFee by remember { mutableStateOf("1200") }
    var newDue by remember { mutableStateOf("10 Nov 2026") }
    val paidCount = members.count { it.paid }
    val pendingCount = members.size - paidCount
    val collected = members.filter { it.paid }.sumOf { it.fee }

    MaterialTheme(colorScheme = darkColorScheme(primary = Lime, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy, floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Lime, contentColor = Navy) { Icon(Icons.Default.Add, "Add member") }
        }) { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 90.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).background(Lime, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.FitnessCenter, null, tint = Navy) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("IRON HOUSE GYM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text("MEMBERSHIP MANAGER", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                        Surface(color = Panel, shape = RoundedCornerShape(20.dp)) { Text("DEMO", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp)) {
                        Text("FEES COLLECTED", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("₹$collected", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                        Text("Current member records · Demo data", color = Muted, fontSize = 11.sp)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("TOTAL", members.size.toString(), Color.White, Modifier.weight(1f))
                        StatCard("PAID", paidCount.toString(), Lime, Modifier.weight(1f))
                        StatCard("PENDING", pendingCount.toString(), Color(0xFFFF8585), Modifier.weight(1f))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, null, tint = Lime)
                        Spacer(Modifier.width(8.dp))
                        Text("Members", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${members.size} total", color = Muted, fontSize = 12.sp)
                    }
                }
                items(members) { member ->
                    MemberCard(member = member, onToggle = {
                        val i = members.indexOf(member)
                        if (i >= 0) { members[i] = member.copy(paid = !member.paid); persist() }
                    }, onRemind = {
                        val msg = "Hello ${member.name}! Your gym membership fee of ₹${member.fee} is due (${member.due}). Please complete your payment. - Iron House Gym"
                        val number = member.phone.filter { it.isDigit() }
                        val uri = Uri.parse("https://wa.me/$number?text=${Uri.encode(msg)}")
                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    })
                }
                item { Text("Demo only: records are saved on this phone. Connect a secure cloud backend before using with real gym members.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp) }
            }
        }
    }
    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false }, containerColor = Panel,
            title = { Text("Add new member", color = Color.White) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(newName, { newName = it }, label = { Text("Member name") }, singleLine = true)
                OutlinedTextField(newPhone, { newPhone = it }, label = { Text("WhatsApp number with country code") }, singleLine = true)
                OutlinedTextField(newFee, { newFee = it }, label = { Text("Monthly fee (₹)") }, singleLine = true)
                OutlinedTextField(newDue, { newDue = it }, label = { Text("Due date") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = {
                val fee = newFee.toIntOrNull()
                if (newName.isNotBlank() && newPhone.isNotBlank() && fee != null && fee > 0) {
                    members.add(Member(newName.trim(), newPhone.filter { it.isDigit() }, fee, newDue, false)); persist()
                    newName = ""; newPhone = ""; newFee = "1200"; newDue = "10 Nov 2026"; showAdd = false
                }
            }) { Text("ADD MEMBER", color = Lime) } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("CANCEL", color = Muted) } }
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, tint: Color, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(13.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(value, color = tint, fontSize = 25.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MemberCard(member: Member, onToggle: () -> Unit, onRemind: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(member.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("₹${member.fee}  ·  Due ${member.due}", color = Muted, fontSize = 11.sp)
            }
            Surface(color = if (member.paid) Color(0xFF263D2D) else Color(0xFF482B31), shape = RoundedCornerShape(30.dp)) {
                Text(if (member.paid) "PAID" else "PENDING", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = if (member.paid) Lime else Color(0xFFFF9292), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onToggle, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
                Icon(Icons.Default.Payments, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text(if (member.paid) "Undo paid" else "Mark paid", fontSize = 11.sp)
            }
            Button(onClick = onRemind, enabled = !member.paid, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Navy), contentPadding = PaddingValues(vertical = 8.dp)) {
                Icon(Icons.Default.NotificationsActive, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("WhatsApp", fontSize = 11.sp)
            }
        }
    }
}

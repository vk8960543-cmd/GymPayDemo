# GymPay Demo – Iron House Gym

A first Android Studio demo for a gym fee manager. It includes:
- A branded Iron House Gym dashboard
- Sample member records and collected/pending totals
- Add-member form
- Mark paid / undo paid
- WhatsApp reminder handoff (opens WhatsApp/browser with a prefilled message)
- Local persistence on this Android device

## Important demo limitations
This is a local prototype, not the production multi-gym service. Data is stored only on the device. There is no owner login, cloud sync, automatic scheduled messaging, payment gateway, backup, or production-grade access control yet. Use fictional/sample data for demonstrations. The WhatsApp action opens a prefilled message; the owner still reviews and sends it.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder (`GymPayDemo`) as an existing project.
3. Allow Android Studio to download the Android Gradle Plugin and dependencies.
4. Install Android SDK Platform 35 when prompted.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Customize the gym branding for another demo
For each separately branded build:
- Change `android:label` in `app/src/main/AndroidManifest.xml`.
- Change the `IRON HOUSE GYM` title in `MainActivity.kt`.
- Change the colours `Navy`, `Panel`, `Lime`, and `Muted` in `MainActivity.kt`.
- Change `applicationId` and `namespace` in `app/build.gradle.kts` to a unique reverse-domain ID for each Play Store app.
- Replace the launcher icon and add the gym's approved logo/assets.

A separate Play Store listing for each gym means each build needs its own unique application ID, signing/release process, store listing, privacy disclosures and review. For a real multi-gym product, a shared secure backend and tenant-level data isolation should be designed before onboarding real customers.
